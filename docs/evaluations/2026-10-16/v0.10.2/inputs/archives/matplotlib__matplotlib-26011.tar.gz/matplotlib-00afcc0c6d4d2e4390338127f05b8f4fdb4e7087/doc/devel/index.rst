.. _developers-guide-index:

##########
Contribute
##########

Thank you for your interest in helping to improve Matplotlib! There are various
ways to contribute: optimizing and refactoring code, detailing unclear
documentation and writing new examples, reporting and fixing bugs and requesting
and implementing new features, helping the community...

.. card::

   .. grid:: 1 1 2 2

      .. grid-item::
         :class: sd-fs-5
         :child-align: spaced

         :octicon:`info;1em;sd-text-info` :ref:`Where should I start? <start-contributing>`

         :octicon:`question;1em;sd-text-info` :ref:`Where should I ask questions? <get_connected>`

         :octicon:`issue-opened;1em;sd-text-info` :ref:`What are "good-first-issues"? <new_contributors>`

         :octicon:`git-pull-request;1em;sd-text-info` :ref:`How do I claim an issue? <managing_issues_prs>`

         .. :octicon:`codespaces;1em;sd-text-info` placeholder for codespaces link

      .. grid-item::

         .. grid:: 1
            :gutter: 1
            :class-row: sd-fs-5

            .. grid-item-card::
               :link: request-a-new-feature
               :link-type: ref

               :octicon:`light-bulb;1em;sd-text-info` Request new feature

            .. grid-item-card::
               :link: submitting-a-bug-report
               :link-type: ref

               :octicon:`bug;1em;sd-text-info` Submit bug report

            .. grid-item-card::
               :link: contributing-code
               :link-type: ref

               :octicon:`code;1em;sd-text-info` Contribute code

            .. grid-item-card::
               :link: documenting-matplotlib
               :link-type: ref

               :octicon:`note;1em;sd-text-info` Write documentation

If you are new to contributing, we recommend that you first read our
:ref:`contributing guide<contributing>`. If you are contributing code or
documentation, please follow our guides for setting up and managing a
:ref:`development environment and workflow<development_environment>`.
For code, documentation, or triage, please follow the corresponding
:ref:`contribution guidelines <contribution_guideline>`.


.. _development_environment:

Development workflow
====================

.. grid:: 1 1 2 2

   .. grid-item-card:: Install

      .. toctree::
         :maxdepth: 2

         development_setup

      .. toctree::
         :maxdepth: 1

         dependencies


   .. grid-item-card:: Workflow

      .. toctree::
         :maxdepth: 2

         development_workflow



.. _contribution_guideline:

Contribution guides
===================

.. grid:: 1 1 2 2
   :class-row: sf-fs-1

   .. grid-item-card:: Code

      | :ref:`coding_guidelines`

      .. toctree::
         :maxdepth: 1

         coding_guide
         testing

   .. grid-item-card:: Documentation

      .. toctree::
         :maxdepth: 1

         document
         style_guide

   .. grid-item-card:: Triage

      | :ref:`bug_triaging`
      | :ref:`triage_team`
      | :ref:`triage_workflow`

   .. grid-item-card:: Maintenance

      .. toctree::
         :maxdepth: 1

         release_guide
         min_dep_policy
         MEP/index

.. toctree::
   :hidden:

   contribute
   triage
   license
   color_changes
