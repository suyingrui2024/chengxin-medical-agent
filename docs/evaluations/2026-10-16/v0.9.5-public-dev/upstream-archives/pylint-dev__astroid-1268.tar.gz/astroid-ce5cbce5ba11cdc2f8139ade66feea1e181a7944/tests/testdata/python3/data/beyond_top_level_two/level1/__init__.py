def func(var):
    pass
