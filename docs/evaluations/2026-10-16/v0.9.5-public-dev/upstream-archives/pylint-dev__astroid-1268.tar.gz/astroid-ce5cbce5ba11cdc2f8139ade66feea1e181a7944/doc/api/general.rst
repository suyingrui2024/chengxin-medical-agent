General API
------------

.. automodule:: astroid
