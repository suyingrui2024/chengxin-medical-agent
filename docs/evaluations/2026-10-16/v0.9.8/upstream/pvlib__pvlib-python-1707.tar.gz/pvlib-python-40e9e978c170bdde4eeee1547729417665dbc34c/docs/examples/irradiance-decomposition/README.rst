Irradiance Decomposition
------------------------

