Irradiance Transposition
------------------------

