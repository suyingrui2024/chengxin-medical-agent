Spectrum
--------
