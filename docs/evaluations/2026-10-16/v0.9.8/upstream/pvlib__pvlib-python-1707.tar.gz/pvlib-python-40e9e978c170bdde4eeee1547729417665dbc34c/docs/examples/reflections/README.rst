Reflections
-----------

