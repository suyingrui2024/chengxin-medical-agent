I-V Modeling
------------

