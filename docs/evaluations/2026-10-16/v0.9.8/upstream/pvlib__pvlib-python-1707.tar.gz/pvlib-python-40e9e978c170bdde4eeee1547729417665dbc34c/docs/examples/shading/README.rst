Shading
-------
