Bifacial Modeling
-----------------

