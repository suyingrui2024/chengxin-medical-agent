"""init py for cli."""
