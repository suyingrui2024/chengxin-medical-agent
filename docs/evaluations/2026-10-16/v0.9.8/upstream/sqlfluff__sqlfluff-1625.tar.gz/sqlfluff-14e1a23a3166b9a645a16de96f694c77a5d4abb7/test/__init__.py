"""Init PY for tests."""
