select a
/*
)
*/
from b