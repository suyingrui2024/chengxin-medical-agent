"""Tests for sqlfluff.cli."""
