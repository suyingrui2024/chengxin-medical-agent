"""Example sqlfluff plugin."""
