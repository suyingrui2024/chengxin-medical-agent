import { test, expect } from "@playwright/test";
import {
  reachDegree,
  degreeSnapshot,
} from "../fixtures/visual-answer-drafts.mjs";

test("unconfirmed body location survives a session switch without writing a result", async ({
  page,
  request,
}) => {
  await request.post("/api/settings", { data: { backend: "demo" } });
  await page.goto("/");
  const id = await reachDegree(page);
  await page.getByRole("button", { name: "3 分", exact: true }).click();
  await page.getByRole("button", { name: "确认 3 分", exact: true }).click();
  const input = page.getByRole("textbox", { name: "输入你的描述" });
  await input.fill("没有");
  await page.getByRole("button", { name: "发送回答" }).click();
  await expect(page.locator(".body-map")).toBeVisible();
  await page
    .locator(".body-map")
    .getByRole("button", { name: "四肢", exact: true })
    .click();
  await input.fill("右臂外侧，稍后再补充。");
  const before = await degreeSnapshot(page, id);
  const created = page.waitForResponse(
    (r) => r.request().method() === "POST" && r.url().endsWith("/api/sessions"),
  );
  await page.locator("#new-session").click();
  await created;
  await page.locator(`#recent-sessions [data-session-id="${id}"]`).click();
  await expect(input).toHaveValue("右臂外侧，稍后再补充。");
  await expect(
    page.getByRole("button", { name: "记录：四肢", exact: true }),
  ).toBeEnabled();
  const restored = await degreeSnapshot(page, id);
  expect(restored.events).toEqual(before.events);
  expect(restored.state.facts).toEqual(before.state.facts);
  expect(restored.state.facts.symptom_location).toBeUndefined();
});
