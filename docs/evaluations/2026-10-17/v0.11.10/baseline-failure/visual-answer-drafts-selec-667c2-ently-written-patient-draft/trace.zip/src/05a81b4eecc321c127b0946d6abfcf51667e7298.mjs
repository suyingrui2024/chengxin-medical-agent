import { test, expect } from "@playwright/test";

test("selecting a visual degree preserves an independently written patient draft", async ({ page, request }) => {
  await request.post("/api/settings", { data: { backend: "demo" } });
  await page.goto("/");
  const created = page.waitForResponse(r => r.request().method() === "POST" && r.url().endsWith("/api/sessions"));
  await page.getByRole("button", { name: "开始问诊", exact: true }).click();
  const id = (await (await created).json()).session_id;
  const answer = async text => {
    await page.getByRole("textbox", { name: "输入你的描述" }).fill(text);
    await page.getByRole("button", { name: "发送回答" }).click();
    await expect(page.locator("#send-button")).toBeEnabled();
  };
  await page.getByRole("button", { name: "我自己", exact: true }).click();
  await answer("32岁"); await answer("头疼");
  await page.getByRole("button", { name: "都没有", exact: true }).click();
  await answer("昨天逐渐出现");
  await page.getByRole("button", { name: "变化不大", exact: true }).click();
  const draft = "昨晚用过药物甲，这段还没有发送。";
  const before = await (await request.get(`/api/sessions/${id}/snapshot`)).json();
  await page.getByRole("textbox", { name: "输入你的描述" }).fill(draft);
  await page.getByRole("button", { name: "5 分", exact: true }).click();
  await expect(page.getByRole("textbox", { name: "输入你的描述" })).toHaveValue(draft);
  const selected = await (await request.get(`/api/sessions/${id}/snapshot`)).json();
  expect(selected.state.facts).toEqual(before.state.facts);
  expect(selected.events).toEqual(before.events);
});
