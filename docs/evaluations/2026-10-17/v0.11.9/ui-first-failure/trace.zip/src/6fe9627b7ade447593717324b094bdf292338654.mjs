import { test, expect } from "@playwright/test";
import {
  createConsultationSubjectsModel,
  verifyConsultationSubjects,
} from "../fixtures/consultation-subjects.mjs";

for (const mobile of [false, true])
  test(`consultation subjects stay separate and new-case text remains editable${mobile ? " on a narrow screen" : ""}`, async ({
    page,
    request,
  }) => {
    const model = await createConsultationSubjectsModel();
    try {
      expect(
        (
          await request.post("/api/settings", {
            data: {
              backend: "compatible",
              base_url: model.endpoint,
              model: "fixture",
              api_key: "subject-ui-only",
            },
          })
        ).ok(),
      ).toBe(true);
      await page.goto("/");
      await verifyConsultationSubjects(page, model, {
        shots: `docs/assets/ui/68-${mobile ? "mobile" : "wide"}-consultation-subject`,
        mobile,
      });
    } finally {
      await request.post("/api/settings", { data: { backend: "demo" } });
      await model.close();
    }
  });
