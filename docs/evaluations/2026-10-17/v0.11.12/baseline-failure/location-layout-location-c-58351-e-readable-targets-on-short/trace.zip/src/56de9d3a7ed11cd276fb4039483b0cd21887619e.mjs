import { test, expect } from "@playwright/test";
import { reachSelfCheck } from "../fixtures/self-check-drafts.mjs";

for (const [label, width, height] of [
  ["wide", 1440, 1080],
  ["mobile", 390, 844],
  ["short", 900, 648],
])
  test(`location controls have separate readable targets on ${label}`, async ({
    page,
    request,
  }) => {
    await request.post("/api/settings", { data: { backend: "demo" } });
    await page.setViewportSize({ width, height });
    await page.goto("/");
    await reachSelfCheck(page);
    const targets = await page
      .locator("#active-task .body-pin")
      .evaluateAll((nodes) =>
        nodes.map((node) => {
          const r = node.getBoundingClientRect();
          return {
            text: node.textContent,
            x: r.x,
            y: r.y,
            width: r.width,
            height: r.height,
          };
        }),
      );
    const overlaps = [];
    for (let i = 0; i < targets.length; i++)
      for (let j = i + 1; j < targets.length; j++) {
        const a = targets[i],
          b = targets[j];
        if (
          Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x) > 0 &&
          Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y) > 0
        )
          overlaps.push([a.text, b.text]);
      }
    await page.screenshot({
      path: `.runtime/location-layout-20261017/baseline-${label}.png`,
      fullPage: true,
    });
    await test
      .info()
      .attach("location-targets", {
        body: JSON.stringify({ targets, overlaps }, null, 2),
        contentType: "application/json",
      });
    expect(targets).toHaveLength(5);
    expect(targets.every((t) => t.width >= 44 && t.height >= 44)).toBe(true);
    expect(overlaps).toEqual([]);
  });
