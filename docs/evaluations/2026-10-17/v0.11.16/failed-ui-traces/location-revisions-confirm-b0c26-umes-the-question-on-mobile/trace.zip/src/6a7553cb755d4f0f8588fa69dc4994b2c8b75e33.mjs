import { test, expect } from "@playwright/test";
import {
  createLocationAnswersModel,
  verifyLocationAnswers,
} from "../fixtures/location-answers.mjs";
import { degreeSnapshot } from "../fixtures/visual-answer-drafts.mjs";

for (const [label, width, height] of [
  ["wide", 1440, 1080],
  ["mobile", 390, 844],
  ["short", 900, 648],
]) {
  test(`confirmed location revision cancels safely and resumes the question on ${label}`, async ({
    page,
    request,
  }) => {
    const model = await createLocationAnswersModel();
    try {
      expect(
        (
          await request.post("/api/settings", {
            data: {
              backend: "compatible",
              base_url: model.endpoint,
              model: "fixture",
              api_key: "location-revision-fixture",
            },
          })
        ).ok(),
      ).toBe(true);
      await page.setViewportSize({ width, height });
      await page.goto("/");
      const { sessionId, result } = await verifyLocationAnswers(page, model);
      const pane = page.locator("#active-task");
      const input = page.getByRole("textbox", { name: "输入你的描述" });
      const start = async () => {
        const control = page.locator("#fact-list .location-revision-start");
        if (!(await control.isVisible()))
          await page.locator("#toggle-facts").click();
        await expect(control).toBeEnabled();
        const box = await control.boundingBox();
        expect(box.height).toBeGreaterThanOrEqual(44);
        await control.click();
        await expect(pane.locator(".location-answer-review")).toBeVisible();
        await expect(
          pane.locator(".location-answer-source summary"),
        ).toHaveText("原记录 · 待核对");
      };
      const chooseLeft = async () => {
        await pane
          .getByRole("button", { name: "左右 · 右侧", exact: true })
          .click();
        await pane.getByRole("button", { name: "左侧", exact: true }).click();
        await pane.getByRole("button", { name: "下一步", exact: true }).click();
        await pane.getByRole("button", { name: "下一步", exact: true }).click();
        await expect(
          pane.getByRole("button", { name: "左右 · 左侧", exact: true }),
        ).toBeVisible();
      };
      await start();
      await chooseLeft();
      await pane
        .getByRole("button", { name: "核对并记录位置", exact: true })
        .evaluate((node) => (window.cancelledLocationConfirm = node));
      await page
        .getByRole("button", { name: "取消修改，保留原记录", exact: true })
        .click();
      await expect(page.locator("#active-question h2")).toBeVisible();
      const cancelled = await degreeSnapshot(page, sessionId);
      expect(cancelled.state.facts.symptom_location).toEqual(result);
      await page.evaluate(() => {
        window.cancelledLocationConfirm.disabled = false;
        window.cancelledLocationConfirm.click();
      });
      expect((await degreeSnapshot(page, sessionId)).events).toEqual(
        cancelled.events,
      );
      await start();
      await chooseLeft();
      await expect(input).toHaveValue("这段用药补充还没有发送。");
      await page.screenshot({
        path: `docs/assets/ui/78-${label}-location-revision.png`,
        fullPage: true,
      });
      await pane
        .getByRole("button", { name: "核对并记录位置", exact: true })
        .click();
      await expect(page.locator("#active-question h2")).toBeVisible();
      const final = await degreeSnapshot(page, sessionId);
      const current = final.state.facts.symptom_location;
      expect(current.supersedes).toBe(result.fact_id);
      expect(current.structured_input.revision_of).toBe(result.fact_id);
      expect(current.structured_input.answers.side.value).toBe("left");
      expect(current.quality).toBe("not_assessed");
      expect(final.state.active_question).toBe("onset");
      expect(
        final.state.history.filter((f) => f.key === "symptom_location"),
      ).toHaveLength(2);
      expect(model.requests).toHaveLength(4);
      await expect(input).toHaveValue("这段用药补充还没有发送。");
    } finally {
      await request.post("/api/settings", { data: { backend: "demo" } });
      await model.close();
    }
  });
}
