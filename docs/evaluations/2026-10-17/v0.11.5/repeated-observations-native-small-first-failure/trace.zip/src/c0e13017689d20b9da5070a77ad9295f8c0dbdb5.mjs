import { _electron as electron, test } from "@playwright/test";
import { mkdtemp, rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  createRepeatedObservationModel,
  verifyRepeatedObservations,
  verifyResumedObservationQuestion,
} from "../fixtures/repeated-observations.mjs";

const root = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "../..",
);
for (const resumeOnly of [false, true])
  test(
    resumeOnly
      ? "native repeat resumes the original question with all options visible"
      : "native repeat observations preserve history, resume and reassess risk",
    async () => {
      const temporary = await mkdtemp(
        path.join(root, ".runtime/native-repeated-observations-"),
      );
      const model = await createRepeatedObservationModel();
      const env = {
        ...process.env,
        MEDAGENT_DESKTOP_PROFILE: path.join(temporary, "profile"),
        MEDAGENT_EXECUTION_ROOT: path.join(temporary, "workspaces"),
        MEDAGENT_DESKTOP_LIVE: "1",
        MEDAGENT_BACKEND: "compatible",
        MEDAGENT_LLM_BASE_URL: model.endpoint,
        MEDAGENT_LLM_MODEL: "fixture",
        MEDAGENT_LLM_API_KEY: "local-observations",
      };
      delete env.ELECTRON_RUN_AS_NODE;
      let app;
      try {
        const executablePath = process.env.MEDAGENT_DESKTOP_BINARY;
        app = await electron.launch({
          executablePath,
          args: executablePath ? [] : [root],
          env,
        });
        if (resumeOnly) {
          await app.evaluate(({ BrowserWindow }) =>
            BrowserWindow.getAllWindows()[0].setSize(900, 760),
          );
          await verifyResumedObservationQuestion(
            await app.firstWindow(),
            model,
          );
        } else await verifyRepeatedObservations(await app.firstWindow(), model);
      } finally {
        await app?.close();
        await model.close();
        await rm(temporary, { recursive: true, force: true });
      }
    },
  );
